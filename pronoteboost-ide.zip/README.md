
  # Review prompt attachment

  This is a code bundle for Review prompt attachment. The original project is available at https://www.figma.com/design/rxfAIiu0bD5RTSukYHwDGJ/Review-prompt-attachment.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  